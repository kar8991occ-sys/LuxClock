package com.luxclock.app

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val requestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.refresh).setOnClickListener { refreshWeather() }
        refreshWeather()
    }

    private fun refreshWeather() {
        val fine = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode)
            status.text = "Разрешите доступ к местоположению, чтобы показывать местную погоду."
            return
        }
        val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val location: Location? = try {
            val providers = manager.getProviders(true)
            providers.mapNotNull { provider -> try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null } }
                .maxByOrNull { it.time }
        } catch (_: Exception) { null }
        if (location == null) {
            status.text = "Не удалось получить координаты. Включите геолокацию и попробуйте ещё раз."
            return
        }
        status.text = "Обновляем погоду…"
        thread {
            try {
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=temperature_2m,weather_code&timezone=auto")
                val connection = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 10000 }
                val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                connection.disconnect()
                val current = json.getJSONObject("current")
                val temp = current.getDouble("temperature_2m").toInt()
                val code = current.getInt("weather_code")
                val description = weatherDescription(code)
                getSharedPreferences("luxclock", MODE_PRIVATE).edit().putString("weather", "$temp°")
                    .putString("condition", description).apply()
                runOnUiThread { status.text = "Погода обновлена: $temp°, $description" }
                updateWidget()
            } catch (_: Exception) {
                runOnUiThread { status.text = "Не удалось обновить погоду. Проверьте интернет и повторите попытку." }
            }
        }
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "Ясно"
        1, 2 -> "Переменная облачность"
        3 -> "Облачно"
        45, 48 -> "Туман"
        in 51..67 -> "Морось или дождь"
        in 71..77 -> "Снег"
        in 80..82 -> "Ливень"
        in 85..86 -> "Снегопад"
        in 95..99 -> "Гроза"
        else -> "Погода обновлена"
    }

    private fun updateWidget() {
        val intent = Intent(this, LuxClockWidget::class.java).apply { action = AppWidgetManager.ACTION_APPWIDGET_UPDATE }
        val ids = AppWidgetManager.getInstance(this).getAppWidgetIds(ComponentName(this, LuxClockWidget::class.java))
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        sendBroadcast(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) refreshWeather()
    }
}

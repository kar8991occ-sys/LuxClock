package com.luxclock.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LuxClockWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("luxclock", Context.MODE_PRIVATE)
        val weather = prefs.getString("weather", "—°") ?: "—°"
        val condition = prefs.getString("condition", "Откройте приложение") ?: "Откройте приложение"
        val date = SimpleDateFormat("EEEE · d MMMM", Locale("ru")).format(Date()).uppercase(Locale("ru"))
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_lux_clock)
            views.setTextViewText(R.id.date, date)
            views.setTextViewText(R.id.weather, "☀  $weather")
            views.setTextViewText(R.id.condition, condition)
            manager.updateAppWidget(id, views)
        }
    }
}
